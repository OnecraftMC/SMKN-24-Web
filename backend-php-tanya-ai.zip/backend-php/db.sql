-- Skema database untuk fitur "Tanya AI" — SMKN 24 Jakarta
-- Cara pakai:
--   mysql -u root -p < db.sql
-- atau import lewat phpMyAdmin.

CREATE DATABASE IF NOT EXISTS smkn24_ai
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE smkn24_ai;

-- Menyimpan setiap sesi chat (1 baris = 1 pengunjung/percakapan)
CREATE TABLE IF NOT EXISTS chat_sessions (
  id            CHAR(32)     NOT NULL PRIMARY KEY,   -- session_id acak dari frontend
  ip_address    VARCHAR(45)  NULL,
  user_agent    VARCHAR(255) NULL,
  created_at    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  last_active_at DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP
                              ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Menyimpan setiap pesan (baik dari pengunjung maupun balasan AI)
CREATE TABLE IF NOT EXISTS chat_messages (
  id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  session_id  CHAR(32)     NOT NULL,
  role        ENUM('user','assistant') NOT NULL,
  message     TEXT         NOT NULL,
  created_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (session_id) REFERENCES chat_sessions(id) ON DELETE CASCADE,
  INDEX idx_session (session_id)
) ENGINE=InnoDB;

-- Menyimpan penghitung rate-limit sederhana per sesi per menit
CREATE TABLE IF NOT EXISTS chat_rate_limit (
  session_id  CHAR(32)  NOT NULL,
  minute_bucket VARCHAR(20) NOT NULL, -- format: YYYY-MM-DD-HH-MM
  request_count INT UNSIGNED NOT NULL DEFAULT 0,
  PRIMARY KEY (session_id, minute_bucket)
) ENGINE=InnoDB;
