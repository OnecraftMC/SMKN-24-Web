# Backend PHP "Tanya AI" — SMKN 24 Jakarta

Backend ini dibuat dengan **PHP + MySQL**. API key AI disimpan di
`config.php` (di server, bukan di browser), dan setiap percakapan
disimpan ke database supaya bisa dilihat/dipantau nanti.

## Kebutuhan

- PHP 8.0+ dengan extension `pdo_mysql` dan `curl` aktif
- MySQL atau MariaDB
- Web server (Apache/Nginx) atau cukup `php -S` untuk tes lokal

## 1. Import database

```bash
mysql -u root -p < db.sql
```

Ini akan membuat database `smkn24_ai` beserta 3 tabel:
- `chat_sessions` — daftar sesi/pengunjung yang chat
- `chat_messages` — isi setiap pesan (dari pengunjung & dari AI)
- `chat_rate_limit` — pencatatan sederhana untuk membatasi spam

## 2. Isi konfigurasi

```bash
cp config.example.php config.php
```

Buka `config.php`, isi:
- `ANTHROPIC_API_KEY` — API key dari https://console.anthropic.com/settings/keys
- `DB_HOST`, `DB_NAME`, `DB_USER`, `DB_PASS` — sesuai setup MySQL kamu
- `ALLOWED_ORIGIN` — domain website sekolah (untuk produksi), atau `*` untuk tes lokal

**Jangan** upload `config.php` ke tempat publik / Git. File `.htaccess` di folder
ini sudah memblokir akses langsung ke `config.php`, `db.php`, dan `db.sql` lewat
browser — tapi ini hanya berlaku di Apache. Kalau pakai Nginx, tambahkan aturan
serupa di konfigurasi server (blokir file `.php` yang bukan di dalam folder `api/`).

## 3. Jalankan untuk tes lokal

```bash
php -S localhost:8000
```

Endpoint yang tersedia: `http://localhost:8000/api/chat.php`

## 4. Hubungkan ke website

Di file `SMK24_JAKARTA.html`, cari baris ini (dekat komentar `RENDER: TANYA AI`):

```js
const AI_BACKEND_URL = "http://localhost:8000/api/chat.php";
```

- Untuk tes lokal, biarkan seperti itu (sesuai langkah 3 di atas).
- Saat website sudah online, ganti ke domain asli, misalnya:
  ```js
  const AI_BACKEND_URL = "https://smkn24jakarta.sch.id/backend-php/api/chat.php";
  ```

## 5. Deploy ke hosting

1. Upload seluruh folder `backend-php/` ke hosting (cPanel/VPS/dst).
2. Buat database MySQL lewat hosting, import `db.sql` (lewat phpMyAdmin atau CLI).
3. Buat `config.php` di server (jangan upload dari komputer kalau hosting publik —
   isi langsung lewat file manager/SSH), isi API key & kredensial database hosting.
4. Pastikan folder `backend-php/` bisa diakses lewat HTTPS.
5. Update `AI_BACKEND_URL` di file HTML ke alamat tersebut.

## Struktur file

```
backend-php/
├── api/
│   └── chat.php           # endpoint yang dipanggil dari website
├── config.example.php     # contoh konfigurasi (salin jadi config.php)
├── db.php                 # helper koneksi database (PDO)
├── db.sql                 # skema database
├── .htaccess               # blokir akses langsung ke file config
└── README.md               # file ini
```

## Melihat riwayat chat

Semua percakapan tersimpan di tabel `chat_messages`. Contoh query untuk
melihat percakapan terbaru:

```sql
SELECT s.id AS session_id, m.role, m.message, m.created_at
FROM chat_messages m
JOIN chat_sessions s ON s.id = m.session_id
ORDER BY m.created_at DESC
LIMIT 50;
```

## Keamanan

- API key hanya ada di `config.php` di server, tidak pernah dikirim ke browser.
- `.htaccess` memblokir akses langsung ke file konfigurasi lewat URL.
- Ada rate-limit per sesi (default 15 pesan/menit, bisa diubah di `config.php`).
- Untuk produksi, sebaiknya set `ALLOWED_ORIGIN` ke domain resmi sekolah (bukan `*`).
- Pertimbangkan untuk menaruh `config.php` di luar folder yang bisa diakses publik
  (document root) jika hosting kamu mendukungnya, untuk keamanan ekstra.
