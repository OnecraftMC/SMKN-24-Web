<?php
/**
 * Endpoint: POST /api/chat.php
 * ------------------------------
 * Menerima pesan dari widget "Tanya AI" di website, meneruskannya ke
 * Anthropic API (API key hanya ada di server, lewat config.php), lalu
 * menyimpan riwayat percakapan ke database sebelum mengirim balasan
 * kembali ke browser.
 *
 * Body request (JSON):
 *   {
 *     "session_id": "abcdef1234...",   // opsional, dibuat otomatis jika kosong
 *     "message": "Kapan jadwal UTS?"
 *   }
 *
 * Response (JSON):
 *   { "reply": "...", "session_id": "abcdef1234..." }
 */

require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../db.php';

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: ' . ALLOWED_ORIGIN);
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

function respond_error(int $code, string $message): void
{
    http_response_code($code);
    echo json_encode(['error' => $message]);
    exit;
}

// ---- 1. Ambil & validasi input ----
$raw = file_get_contents('php://input');
$body = json_decode($raw, true);

if (!is_array($body) || empty($body['message']) || !is_string($body['message'])) {
    respond_error(400, 'Field "message" wajib diisi.');
}

$userMessage = trim(mb_substr($body['message'], 0, 2000)); // batasi panjang pesan
if ($userMessage === '') {
    respond_error(400, 'Pesan tidak boleh kosong.');
}

$sessionId = $body['session_id'] ?? '';
if (!preg_match('/^[a-f0-9]{32}$/', $sessionId)) {
    $sessionId = bin2hex(random_bytes(16)); // buat session_id baru jika tidak valid
}

try {
    $db = get_db();

    // ---- 2. Pastikan sesi tercatat ----
    $stmt = $db->prepare(
        'INSERT INTO chat_sessions (id, ip_address, user_agent)
         VALUES (:id, :ip, :ua)
         ON DUPLICATE KEY UPDATE last_active_at = CURRENT_TIMESTAMP'
    );
    $stmt->execute([
        ':id' => $sessionId,
        ':ip' => $_SERVER['REMOTE_ADDR'] ?? null,
        ':ua' => substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 255),
    ]);

    // ---- 3. Rate limit sederhana per sesi per menit ----
    $bucket = date('Y-m-d-H-i');
    $stmt = $db->prepare(
        'INSERT INTO chat_rate_limit (session_id, minute_bucket, request_count)
         VALUES (:sid, :bucket, 1)
         ON DUPLICATE KEY UPDATE request_count = request_count + 1'
    );
    $stmt->execute([':sid' => $sessionId, ':bucket' => $bucket]);

    $stmt = $db->prepare(
        'SELECT request_count FROM chat_rate_limit WHERE session_id = :sid AND minute_bucket = :bucket'
    );
    $stmt->execute([':sid' => $sessionId, ':bucket' => $bucket]);
    $count = (int) $stmt->fetchColumn();

    if ($count > RATE_LIMIT_PER_MINUTE) {
        respond_error(429, 'Terlalu banyak permintaan. Coba lagi sebentar lagi.');
    }

    // ---- 4. Ambil riwayat percakapan (20 pesan terakhir) untuk konteks ----
    $stmt = $db->prepare(
        'SELECT role, message FROM chat_messages
         WHERE session_id = :sid
         ORDER BY id DESC LIMIT 20'
    );
    $stmt->execute([':sid' => $sessionId]);
    $history = array_reverse($stmt->fetchAll());

    $messagesForApi = array_map(fn($row) => [
        'role'    => $row['role'],
        'content' => $row['message'],
    ], $history);
    $messagesForApi[] = ['role' => 'user', 'content' => $userMessage];

    // ---- 5. Simpan pesan pengguna ke database ----
    $stmt = $db->prepare(
        'INSERT INTO chat_messages (session_id, role, message) VALUES (:sid, "user", :msg)'
    );
    $stmt->execute([':sid' => $sessionId, ':msg' => $userMessage]);

    // ---- 6. Panggil Anthropic API ----
    $systemPrompt = <<<PROMPT
Kamu adalah asisten AI resmi untuk website SMKN 24 Jakarta.
Tugasmu menjawab pertanyaan pengunjung website (siswa, orang tua, calon siswa)
seputar informasi sekolah secara singkat, ramah, dan dalam Bahasa Indonesia.

Info dasar sekolah:
- Nama: SMKN 24 Jakarta, berlokasi di Jl. Melati Raya No. 45, Jakarta Selatan, 12230.
- Jam operasional kantor: Senin-Jumat, 07.00-15.30 WIB.
- Kontak: (021) 555-0142, info@cendekiabangsa.sch.id

Jika ditanya hal yang sangat spesifik dan kamu tidak yakin datanya (misalnya
nominal SPP terbaru, hasil ujian, atau data pribadi siswa), sarankan pengunjung
untuk menghubungi pihak sekolah langsung lewat kontak di atas alih-alih menebak.
Jangan pernah mengarang kebijakan resmi sekolah. Jawab secara ringkas (idealnya
di bawah 120 kata) kecuali diminta penjelasan lebih detail.
PROMPT;

    $payload = [
        'model'      => ANTHROPIC_MODEL,
        'max_tokens' => 500,
        'system'     => $systemPrompt,
        'messages'   => $messagesForApi,
    ];

    $ch = curl_init('https://api.anthropic.com/v1/messages');
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => json_encode($payload),
        CURLOPT_HTTPHEADER     => [
            'Content-Type: application/json',
            'x-api-key: ' . ANTHROPIC_API_KEY,
            'anthropic-version: 2023-06-01',
        ],
        CURLOPT_TIMEOUT        => 30,
    ]);
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curlError = curl_error($ch);
    curl_close($ch);

    if ($response === false) {
        respond_error(502, 'Gagal menghubungi server AI: ' . $curlError);
    }

    $data = json_decode($response, true);

    if ($httpCode >= 400) {
        error_log('Anthropic API error: ' . $response);
        respond_error(502, 'Server AI mengembalikan error.');
    }

    $replyText = '';
    foreach ($data['content'] ?? [] as $block) {
        if (($block['type'] ?? '') === 'text') {
            $replyText .= $block['text'];
        }
    }
    $replyText = trim($replyText) ?: 'Maaf, saya belum bisa menjawab pertanyaan itu.';

    // ---- 7. Simpan balasan AI ke database ----
    $stmt = $db->prepare(
        'INSERT INTO chat_messages (session_id, role, message) VALUES (:sid, "assistant", :msg)'
    );
    $stmt->execute([':sid' => $sessionId, ':msg' => $replyText]);

    // ---- 8. Kirim balasan ke frontend ----
    echo json_encode([
        'reply'      => $replyText,
        'session_id' => $sessionId,
    ]);
} catch (PDOException $e) {
    error_log('DB error: ' . $e->getMessage());
    respond_error(500, 'Terjadi kesalahan database di server.');
} catch (Throwable $e) {
    error_log('Server error: ' . $e->getMessage());
    respond_error(500, 'Terjadi kesalahan di server.');
}
