<?php
/**
 * Konfigurasi backend Tanya AI — SMKN 24 Jakarta
 * ------------------------------------------------
 * 1. Salin file ini menjadi "config.php" (di folder yang sama).
 * 2. Isi nilai-nilai di bawah dengan data kamu sendiri.
 * 3. JANGAN upload "config.php" ke tempat publik / commit ke Git.
 *    File ".htaccess" di folder ini sudah memblokir akses langsung
 *    ke file config lewat browser, tapi tetap jaga baik-baik.
 */

// ==== API KEY AI ====
// Dapatkan dari https://console.anthropic.com/settings/keys
define('ANTHROPIC_API_KEY', 'sk-ant-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');

// Model yang dipakai untuk menjawab chat.
define('ANTHROPIC_MODEL', 'claude-sonnet-5');

// ==== DATABASE (MySQL / MariaDB) ====
define('DB_HOST', 'localhost');
define('DB_NAME', 'smkn24_ai');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_CHARSET', 'utf8mb4');

// ==== CORS ====
// Domain yang diizinkan mengakses backend ini. Untuk pengetesan lokal
// boleh "*". Saat sudah online, ganti ke domain website sekolah, misalnya:
// 'https://smkn24jakarta.sch.id'
define('ALLOWED_ORIGIN', '*');

// ==== RATE LIMIT ====
// Maksimal jumlah pesan yang boleh dikirim 1 sesi dalam 1 menit.
define('RATE_LIMIT_PER_MINUTE', 15);
